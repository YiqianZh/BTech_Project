%{
    Note : Set the Current Directory to Cipic Database where HRIRs of all subjects present
    My Path : C:\Users\charishma\Downloads\CIPIC_hrtf_database\standard_hrir_database
%}

% DATA PRE-PROCESSING
% Step - 1: Loading Hrir Data
files = dir('sub*'); % Structure of all files starting with 'sub' in a current directory 
fileNames = {files.name}; % Array of all names of files
totalNumOfSubjects = size(fileNames); % Gives size of an array
maxSize = totalNumOfSubjects(2); % Gives MaxLimit of an array i.e., totalCount of subjects considering

% Step - 2: Getting DataSet
for i = 1 : maxSize
    subject = fileNames{i}; % Getting one by one subject
    load([subject '\hrir_final.mat']); % Loading HRIR of particular Subject
    dataMatrix = hrir_l(13,8,:);  % considering particular direction 
    hrirDataMatrix(:,i) = dataMatrix(1,1,:); % Every row of hrirDataMatrix corresponds to hrir_l of each subject
end

% Step - 3: Optimizing DataSet
% Considering only samples from 35 to 85, as 0 - 35 and 85 - 200 can be ignored by taking into account of hrirDataMatrix plot 
optimizedHrirDataMatrix = hrirDataMatrix(35:85,:);

% If X is a matrix, then fft(X) treats the columns of X as vectors and returns the Fourier transform of each column.
n = 2^nextpow2(size(optimizedHrirDataMatrix,1));
hrtfMatrix = fft(optimizedHrirDataMatrix,n);

% Step - 4: Data Normalization
for i = 1 : n
    % zeroMeanedHrirDataMatrix is a matrix with zero mean 
    zeroMeanedHrtfMatrix(i,:) = hrtfMatrix(i,:) - mean(hrtfMatrix(i,:));
end

% PRINCIPAL COMPONENT ANALYSIS
% Step - 5: Co-Variance Matrix Calculation
% Do Transpose because in zeroMeanedHrirDataMatrix row represents subject and column represents samples. We need samples as rows to find covariance 
covarianceMatrix = cov(transpose(zeroMeanedHrtfMatrix));

% Step - 6: Eigen Vector calculation
[V,eigenvalues] = eig(covarianceMatrix);  
eigenvalues = diag(eigenvalues); % Diagonal Elements represents Eigen values

 eigenThreshold = 0.000; % Should set like where we get a less relative error 
% eigenVector = V(:,find(eigenvalues == max(eigenvalues)));
eigenVector = V(:,find(eigenvalues > eigenThreshold)); % Considering only eigen vectors whose eigen values are greater than given threshold

% Step - 7: Deriving New DataSet
newHrtfMatrix = transpose(conj(eigenVector)) * zeroMeanedHrtfMatrix;

% Step - 8: Reconstruct original Dataset from new Dataset
recostructedHrtfMatrix = eigenVector * newHrtfMatrix;

% Step -9: Relative Error Calculation
for i = 1:maxSize
    reconstructedDataVector = recostructedHrtfMatrix(:,i); 
    originalDataVector = zeroMeanedHrtfMatrix(:,i);
    relativeError(:,i) = (norm(reconstructedDataVector - originalDataVector))/norm(originalDataVector); 
end

relativeErrorMax = max(relativeError);
