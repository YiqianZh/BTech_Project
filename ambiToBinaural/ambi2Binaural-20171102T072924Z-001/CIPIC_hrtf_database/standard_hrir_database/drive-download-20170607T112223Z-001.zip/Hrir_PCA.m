%{
    Note : Set the Current Directory to Cipic Database where HRIRs of all subjects present
    My Path : C:\Users\charishma\Downloads\CIPIC_hrtf_database\standard_hrir_database
%}

% DATA PRE-PROCESSING
% Step - 1: Loading Hrir Data
files = dir('sub*'); % Structure of all files starting with 'sub' in a current directory 
fileNames = {files.name}; % Array of all names of files
totalNumOfSubjects = size(fileNames); % Gives size of an array
maxSize = totalNumOfSubjects(2); % Gives MaxLimit of an array i.e., totalCount of subjects considering

% Step - 2: Getting DataSet
for i = 1 : maxSize
    subject = fileNames{i}; % Getting one by one subject
    load([subject '\hrir_final.mat']); % Loading HRIR of particular Subject
    dataMatrix = hrir_l(13,8,:);  % considering particular direction 
    hrirDataMatrix(:,i) = dataMatrix(1,1,:); % Every row of hrirDataMatrix corresponds to hrir_l of each subject
end

% Step - 3: Optimizing DataSet
% Considering only samples from 35 to 85, as 0 - 35 and 85 - 200 can be ignored by taking into account of hrirDataMatrix plot 
optimizedHrirDataMatrix = hrirDataMatrix(35:85,:);

% Step - 4: Data Normalization
for i = 1 : maxSize
    % zeroMeanedHrirDataMatrix is a matrix with zero mean 
    zeroMeanedHrirDataMatrix(i,:) = optimizedHrirDataMatrix(i,:) - mean(optimizedHrirDataMatrix(i,:));
end

% PRINCIPAL COMPONENT ANALYSIS
% Step - 5: Co-Variance Matrix Calculation
% Do Transpose because in zeroMeanedHrirDataMatrix row represents subject and column represents samples. We need samples as rows to find covariance 
covarianceMatrix = cov(transpose(zeroMeanedHrirDataMatrix));

% Step - 6: Eigen Vector calculation
[V,eigenvalues] = eig(covarianceMatrix);  
eigenvalues = diag(eigenvalues); % Diagonal Elements represents Eigen values


eigenThreshold = 0.0005; % Should set like where we get a less relative error 
eigenVector = V(:,find(eigenvalues == max(eigenvalues)));
% eigenVector = V(:,find(eigenvalues > eigenThreshold)); % Considering only eigen vectors whose eigen values are greater than given threshold

% Step - 7: Deriving New DataSet
newHrirDataMatrix = transpose(eigenVector) * zeroMeanedHrirDataMatrix;

% Step - 8: Reconstruct original Dataset from new Dataset
recostructedHrirDataMatrix = eigenVector * newHrirDataMatrix;

% Step -9: Relative Error Calculation
for i = 1:maxSize
    reconstructedDataVector = recostructedHrirDataMatrix(:,i); 
    originalDataVector = zeroMeanedHrirDataMatrix(:,i);
    relativeError(:,i) = (norm(reconstructedDataVector - originalDataVector))/norm(originalDataVector); 
end

relativeErrorMax = max(relativeError);


% Load Anthropometric Features Data
load('anthor2.mat'); % Modified AnthropometricData within CIPICDatabase.Modification was,label encoding to age column(i.e.,Converting M/F to 1/0)

% Getting Anthropometric Features Data
anthroDataMatrix = horzcat(D,WeightKilograms,X,age,id,sex,theta); 
anthroDataMatrix = transpose(anthroDataMatrix);

% Calculation of Correlation Coeff between Features and newHrirData
numFeatures = length(anthroDataMatrix(:,1));
reducedDim = length(newHrirDataMatrix(:,1));
correlationMatrix = zeros(numFeatures, reducedDim);

for i = 1 : numFeatures
    for j = 1 : reducedDim
        correlation = corrcoef(anthroDataMatrix(i,:),newHrirDataMatrix(j,:),'rows','complete');
        correlationMatrix(i,j) = correlation(1,2);
    end
end

%figure, surf(abs(correlationMatrix));
%figure, scatter(anthroDataMatrix(9,:), newHrirDataMatrix(3,:));
%figure, scatter(anthroDataMatrix(19,:), newHrirDataMatrix(18,:));


% Eliminating Right Ear Features
leftAnthroData = anthroDataMatrix([1:8,17:39],:);

% CREATING A NEURAL NETWORK

% Assigning inputs and targets to a Network
inputs = leftAnthroData; % Considered Head&Torso and only LeftEar Measurements
targets = newHrirDataMatrix; % Data Matrix after PCA

% Create a Fitting Network
net = fitnet(20); % Single Layer with 50 neurons
% net = fitnet([50 50]); % Two Layes with 50 neurons each

% Dividing inputData into train, validation and test datasets.
net.divideParam.trainRatio = 70/100;
net.divideParam.valRatio = 15/100;
net.divideParam.testRatio = 15/100;

% Train the Network
net.trainFcn = 'trainbr'; % Using 
[net,tr] = train(net,inputs,targets);

% Test the Network
outputs = net(inputs);
errors = gsubtract(outputs,targets);
performance = perform(net,targets,outputs);


figure, plotregression(targets,outputs)
figure, plotperform(tr)
